function jrc1(varargin)
% calls jrclust

%jrclust(varargin{:});
disp('Running jrclust.m (ver. 1)');
jrc3(varargin{:});